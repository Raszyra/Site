#include "..\Libraries\global_utils.h"
#include <conio.h>

using namespace std;
using namespace utils;

int level = 1;

struct player
{
    int pos_x, pos_y, score;

    void showScore(){cout << "Score:" << score;}
} p;
struct area
{
    string symbol = "-";
    int col1, col2;

    void display(){
        cout << "[";
        if (symbol == "O") colSet(roll(15), symbol);
        else if (symbol == "#") colSet(COL_RED, symbol);
        else cout << symbol;
        cout << "]";
    }

    void displayPlayer(){
        cout << "[";
        colSet(COL_LIME, "x");
        cout << "]";}

} game_map[10][10];

void initMap()
{
    for (int y = 0; y < 10; y++)
        for (int x = 0; x < 10; x++)
            game_map[x][y].symbol = "-";
}

void randomizeMaguffins()
{
    for (int y = 0; y < 10; y++)
        for (int x = 0; x < 10; x++)
        {
            if ( rollfor(1, 10) ) game_map[x][y].symbol = "O";
            if ( rollfor(1, 10) ) game_map[x][y].symbol = "#";

        }
    game_map[0][0].symbol = "-";
}

bool checkReset()
{
    for (int y = 0; y < 10; y++)
        for (int x = 0; x < 10; x++)
            if ( game_map[x][y].symbol == "O" ) return 0;
    return 1;
}

void reset()
{
    p.pos_x = 0;
    p.pos_y = 0;
    initMap();
    randomizeMaguffins();
}

void drawMap()
{
    for (int y = 0; y < 10; y++){
        for (int x = 0; x < 10; x++){
            if (p.pos_x == x && p.pos_y == y) game_map[x][y].displayPlayer();
            else game_map[x][y].display();
        }
        cout << "\n";
    }
}

string update_input()
{
    if (_kbhit())
    {
        int ch = _getch();
        if (ch == 0 || ch == 224){
            int special_char = _getch();
            switch(special_char){
                case 72: {if (p.pos_y > 0) p.pos_y--;} break;
                case 80: {if (p.pos_y < 9) p.pos_y++;} break;
                case 75: {if (p.pos_x > 0) p.pos_x--;} break;
                case 77: {if (p.pos_x < 9) p.pos_x++;} break;
            }
        }
        switch(ch) {
            case 'w': {if (p.pos_y > 0) p.pos_y--;} break;
            case 's': {if (p.pos_y < 9) p.pos_y++;} break;
            case 'a': {if (p.pos_x > 0) p.pos_x--;} break;
            case 'd': {if (p.pos_x < 9) p.pos_x++;} break;
            case 'q': return "quit"; break;
        }
    }

    if (game_map[p.pos_x][p.pos_y].symbol == "O")
    {
        p.score++;

        game_map[p.pos_x][p.pos_y].symbol = "_";
        utils::play_sound("./audio/sdDing", 0, 0);
    }
    if (game_map[p.pos_x][p.pos_y].symbol == "#")
    {
        reset();
        return "quit";
    }

    return "null";
}

void showTitle()
{
    cout << "TEMPLE WALK\n\n";
    cout <<"Collect the flashing "; colSet(roll(15), "O"); cout << " treasures and avoid the dangerous "; colSet(COL_RED, "#"); cout << " traps.\n";
    cout << "\nUse the arrow keys or WASD to navigate.\nPress 'q' to exit.\n\n";
}

void draw()
{
    string input = "";
    bool is_running = true;
    int time_elapsed = 0;
    int frame = 0;
    char chars[4] = {'\\', '|', '/', '-'};

    while (is_running){

        //Draw static
        showTitle();

        cout << "Game Status:\n";
        if (is_running) {
            cout << "[";
            cout << chars[frame];
            cout << "]";
            cout << " Running";
        }
        else {
            cout << "[X]";
            cout << " Stopped";
        }

        cout << "\n\n";
        cout << "Level: " << level;
        cout << "\n\n";
        p.showScore();
        cout << "\n\n";

        drawMap();

        input = update_input();

        //Increase increment
        time_elapsed++;
        //progress animation frame
        if (frame < 3) frame++;
        else frame = 0;
        //Frame limiter (sleep for 60ms = 60fps)
        Sleep(30);
        //Clear screen for redraw
        cls();
        //Reset if all items are gone
        if (checkReset()) {reset(); level++;}

        if (input == "quit") is_running = false;
    }
}

int main()
{
    string input = "";

    srand(time(NULL));

    do
    {
        randomizeMaguffins();

        draw();

        cout << "\nGAME OVER\n\n\nPlay again? (Y / N)\n";
        input = getInps();
    } while ( input != "n" && input != "N" );

    return 0;
}
