TEMPLE WALK
version: 1.0.0
License: GNU GPL v03


Description:

A simple collect-the-items game running in the console at a stunning 30fps.



Instructions:

Collect the flashing 'O' treasures, and avoid the deadly '#' traps.

Navigate using the arrow keys or WASD.
Press 'q' to quit.


- Note: It's possible to spawn in a temple with no exits or paths to all the treasure.
	You'll have to 'q'uit to respawn (or sacrifice yourself against a wall.)




Send any questions, comments or suggestions to:
  -> Faction7entertainment@gmail.com <-

Happy walking!




DISCLAIMER:
+--------------------------------------------------------+

This software is provided as-is, without any warranties or guarantees of any kind, either express or implied, including but not limited to the implied warranties of merchantability, fitness for a particular purpose, or non-infringement. 

In no event shall the authors or copyright holders be held liable for any claim, damages, or other liability, whether in an action of contract, tort, or otherwise, arising from, out of, or in connection with the software or the use or other dealings in the software.

You can access the full text of the GNU General Public License (GPL) version 3 at the following link:

[GNU GPL v3 License] 
https://www.gnu.org/licenses/gpl-3.0.html

+--------------------------------------------------------+